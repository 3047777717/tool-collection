# Emby 图片 API 调用说明

## 接口地址

```
https://img.frp304777.xyz
```

## 管理面板

**浏览器直接访问**（端口 8801）：

```
https://img.frp304777.xyz:8801/admin
```

输入管理员账号密码即可进入面板，支持：
- **一键创建/复制/吊销 API Key**
- **查看所有调用记录**（按日期筛选、翻页）

无需记住任何命令，点点点就行。

---

## 管理员 API 接口

> 如果不用面板，也可以直接用 API 操作。以下接口需要 `admin_user` + `admin_pass` 参数（即 `.env` 中配置的账号密码）。所有接口均在 **8801 端口**。

### 1. 创建 API Key

> 端口 **8801**

```
POST /admin/keys?admin_user={user}&admin_pass={pass}
Content-Type: application/json

{"name": "我的博客"}
```

返回：

```json
{
  "id": "a1b2c3d4",
  "key": "imgapi-e7f3a91c2b5d6084",
  "name": "我的博客",
  "message": "密钥创建成功，请妥善保管"
}
```

> 创建后把 `key` 发给调用方即可。

### 2. 列出所有 API Key

```
GET /admin/keys?admin_user={user}&admin_pass={pass}
```

返回：

```json
{
  "keys": [
    {"id": "a1b2c3d4", "key": "imgapi-e7f3...", "name": "我的博客", "created_at": "2026-05-29 20:00:00", "active": 1},
    {"id": "e5f6g7h8", "key": "imgapi-4d9c...", "name": "手机App", "created_at": "2026-05-28 15:30:00", "active": 1}
  ],
  "total": 2
}
```

### 3. 吊销 API Key

```
DELETE /admin/keys/{key_id}?admin_user={user}&admin_pass={pass}
```

返回：

```json
{"id": "a1b2c3d4", "key": "imgapi-e7f3...", "name": "我的博客", "active": false, "message": "密钥已吊销"}
```

> 吊销后该 Key 立刻失效，但调用记录保留。

### 4. 查看调用记录

```
GET /admin/logs?admin_user={user}&admin_pass={pass}&page=1&limit=50
```

可选筛选参数：

| 参数 | 说明 |
|---|---|
| `key_id` | 按密钥 ID 筛选（只查某一个 Key 的调用） |
| `date_from` | 起始日期，格式 `2026-05-01` |
| `date_to` | 结束日期，格式 `2026-05-29` |

返回：

```json
{
  "total": 12890,
  "page": 1,
  "limit": 50,
  "logs": [
    {
      "id": 1,
      "api_key_id": "a1b2c3d4",
      "api_key_name": "张三的Key",
      "caller": "我的博客",
      "ip_address": "123.45.67.89",
      "user_agent": "Mozilla/5.0 ...",
      "endpoint": "/photos/54194",
      "image_id": "54194",
      "image_name": "_DSC0061",
      "status_code": 200,
      "created_at": "2026-05-29 20:05:00"
    }
  ]
}
```

每条记录包含：**软件名**（caller，调用方自报）、**API 名**（api_key_name，Key 创建时命名）、**IP 地址**、**UA**、**调了什么接口**、**图片 ID 和名字**、**时间**、**HTTP 状态码**。

---

## 鉴权

所有业务请求需携带 `key` 参数，同时**建议**携带 `caller` 参数标明调用方身份。

| 参数 | 必填 | 说明 |
|---|---|---|
| `key` | 是 | API 密钥，由管理员创建 |
| `caller` | 是 | 软件/网站名，会显示在调用记录中，方便区分来源 |

示例：

```html
<img src="https://img.frp304777.xyz/photos/random?key=imgapi-xxx&caller=我的博客&width=800" />
```

---

## 0. 健康检查

```
GET /?key={api_key}
```

无需 key。返回示例：

```json
{"status": "ok", "photos": 430809, "cache_age_s": 12.5}
```

- `status: "starting"` — 服务刚启动，缓存加载中
- `status: "ok"` — 就绪

---

## 常见错误码

| 状态码 | 含义 | 处理方式 |
|---|---|---|
| 403 | key 参数错误/缺失/已吊销 | 联系管理员获取新 Key |
| 404 | 照片不存在（偶发） | 随机接口会自动换一张重试 |
| 503 | 服务不可用 | 见下方说明 |

### 503 的两种情况

**情况 A**：服务器进程正常运行，但缓存还没加载完。响应体为：
```json
{"detail": "服务正在启动，图片缓存加载中，请稍后重试"}
```
→ 等 1-2 分钟，缓存加载完就恢复正常。

**情况 B**：服务器进程挂了（frp/nginx 连不上后端）。响应体为空或反向代理默认页。
→ 检查服务状态：`sudo systemctl status emby-image-api`，必要时重启。

区分方法：访问 `https://img.frp304777.xyz/`，能返回 JSON 就是情况 A，完全无法访问就是情况 B。

---

## 1. 获取照片列表（推荐入口）

自动发现 Emby 中所有照片，**无需媒体库 ID**。

```
GET /photos?key={api_key}&page=1&limit=50
```

| 参数 | 必填 | 说明 |
|---|---|---|
| `key` | 是 | API 密钥 |
| `page` | 否 | 页码，默认 1 |
| `limit` | 否 | 每页数量，默认 50，最大 500 |

返回示例：

```json
{
  "total": 430809,
  "page": 1,
  "limit": 50,
  "photos": [
    {
      "id": "54194",
      "name": "_DSC0061",
      "url": "/photos/54194?key=xxx",
      "thumbnail": "/photos/54194?key=xxx&width=400"
    }
  ]
}
```

> 缓存未就绪时返回 503 `"服务正在启动，图片缓存加载中，请稍后重试"`。

---

## 2. 获取照片图片

```
GET /photos/{item_id}?key={api_key}&width=800&quality=90
```

| 参数 | 必填 | 说明 |
|---|---|---|
| `item_id` | 是 | 照片 ID（从列表接口获取） |
| `key` | 是 | API 密钥 |
| `caller` | 是 | 调用方标识（软件/网站名） |
| `width` | 否 | 图片宽度（1-4096），不传返回原图 |
| `quality` | 否 | JPEG 质量（1-100，默认 90） |

调用示例：

```html
<img src="https://img.frp304777.xyz/photos/54194?key=imgapi-xxx&caller=我的博客&width=800" />
```

---

## 3. 随机图片

直接返回一张随机照片，适合做网站背景、随机图。

```
GET /photos/random?key={api_key}&caller={caller}&width=1920&quality=85
```

```html
<img src="https://img.frp304777.xyz/photos/random?key=imgapi-xxx&caller=我的博客&width=1920" />
```

> 缓存未就绪时返回 503，请稍后重试。

---

## 4. 影视图片（兼容旧版）

需要知道 Emby 媒体条目 ID，一般用于影视海报/背景。

```
GET /images/{item_id}/{image_type}?key={api_key}&width=400
```

图片类型: Primary(海报) / Backdrop(背景) / Logo / Thumb / Banner / Disc / BoxRear / Menu / Art / Chapter
